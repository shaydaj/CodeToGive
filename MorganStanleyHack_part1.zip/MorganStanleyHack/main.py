import random

import pygame
from pygame.locals import *

pygame.init()
width = 1000
height = 500
window = pygame.display.set_mode((width, height))
bg_img = pygame.image.load('Images/bg1.png')
bg_img = pygame.transform.scale(bg_img, (int(width // 2), height))
game_height = int(height // 2.1)
game_width = int(width // 2)
def animal():
    #banana_list = ['Images/Banana.png', 'Images/Banana-Clipart.png', 'Images/banana-transparent.png','Images/peeled-banana.png']
    bg_img = pygame.image.load('Images/gorilla_up.png')
    bg_image = pygame.transform.scale(bg_img, (int(width // 8), int(height // 7)))
    return bg_image
def banana_drop():
    banana_list = ['Images/Banana.png', 'Images/Banana-Clipart.png', 'Images/banana-transparent.png', 'Images/peeled-banana.png']
    bg_img = pygame.image.load(random.choice(banana_list))
    bg_image = pygame.transform.scale(bg_img, (int(width // 15), int(height // 15)))
    return bg_image



i = 0
banana_pic = banana_drop()
animal_pic = animal()
runing = True
while runing:
    window.fill((0, 0, 0))
    window.blit(bg_img, (game_width, i))
    window.blit(bg_img, (game_width, i - height))
    window.blit(banana_pic, (int(game_width//3), i))
    window.blit(animal_pic, (game_width , int(height//2)))
    if (i == height):
        window.blit(bg_img, (game_width, height))
        i = 0
        banana_pic = banana_drop()
    i += 1
    for event in pygame.event.get():
        if event.type == QUIT:
            runing = False
    pygame.display.update()
pygame.quit()
